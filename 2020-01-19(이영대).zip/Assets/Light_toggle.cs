﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Light_toggle : MonoBehaviour
{
    GameObject[] Pin;
    GameObject[] Light;
    GameObject[] Switch;
    GameObject Player;
    float WaitTime = 8f;
    float CurrTime;

    // Start is called before the first frame update
    void Start()
    {
        Pin = GameObject.FindGameObjectsWithTag("Pin");
        Light = GameObject.FindGameObjectsWithTag("Light");
        Switch = GameObject.FindGameObjectsWithTag("Switch");
        Player = GameObject.FindGameObjectWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {
        for (int i = 0; i < Switch.Length; i++)
        {
            for (int j = 0; j < Pin.Length; j++)
            {
                if (this == Switch[i])
                {
                    if (Pin[j].transform.position.x >= Switch[i].transform.position.x - 0.15f && Pin[j].transform.position.x <= Switch[i].transform.position.x + 0.15f && Pin[j].transform.position.y == Switch[i].transform.position.y)
                    {
                        if (Player.transform.position.x >= Switch[i].transform.position.x - 0.15f && Player.transform.position.x <= Switch[i].transform.position.x + 0.15f && Player.transform.position.y == Switch[i].transform.position.y)
                        {
                            Light[i].SetActive(false);
                            CurrTime += Time.deltaTime;
                            break;
                        }
                    }
                }
            }
            if (CurrTime >= WaitTime)
                Light[i].SetActive(true);
            break;
        }

    }
}
