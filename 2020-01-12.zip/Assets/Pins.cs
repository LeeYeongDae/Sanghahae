﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pins : MonoBehaviour
{
    public static int waypointIndex = 0;
    public GameObject pin;
    Vector2 Pin;
    Camera Camera;
    Transform parent_pin;
    GameObject[] Ladder;
    GameObject[] Door;

    void Start()
    {
        Camera = GameObject.Find("Main Camera").GetComponent<Camera>();
        parent_pin = GameObject.Find("Pins").GetComponent<Transform>();
        Ladder = GameObject.FindGameObjectsWithTag("Ladder");
        Door = GameObject.FindGameObjectsWithTag("Door");
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Pin = Input.mousePosition;
            Pin = Camera.ScreenToWorldPoint(Pin);
            if (Pin.y >= -3.75f && Pin.y <= -1.85f)
                Pin.y = -3.15f;
            if (Pin.y > -1.85f && Pin.y <= 0.1f)
                Pin.y = -1.3f;
            if (Pin.y > 0.1f && Pin.y <= 1.95f)
                Pin.y = 0.65f;
            if (Pin.y > 1.95f && Pin.y <= 3.8f)
                Pin.y = 2.5f;
            waypointIndex++;
            createPin("" + waypointIndex + "");


            //설치 제한

            GameObject StartPin = GameObject.Find("Start");
            GameObject CurrentPin = GameObject.Find("" + waypointIndex + "");
            GameObject PreviousPin = GameObject.Find("" + (waypointIndex - 1) + "");
            if (waypointIndex <= 1)
                PreviousPin = StartPin;

            float PinDistance = (CurrentPin.transform.position.x - PreviousPin.transform.position.x);
            /*
                for (int i = 0; i < Door.Length; i++)
                {
                    float DoorDistance = (Door[i].transform.position.x - PreviousPin.transform.position.x);
                    if (Door[i].transform.position.y == -2.876f && PreviousPin.transform.position.y == -3.15f)
                    {
                        if (PinDistance > 0)
                            if (PinDistance > DoorDistance)
                            {
                                Destroy(CurrentPin);
                                waypointIndex--;
                            }
                            else if (PinDistance < 0)
                                if (PinDistance < DoorDistance)
                                {
                                    Destroy(CurrentPin);
                                    waypointIndex--;
                                }
                    }
                    else if (Door[i].transform.position.y == -0.99f && PreviousPin.transform.position.y == -1.3f)
                    {
                        if (PinDistance > 0)
                            if (PinDistance > DoorDistance)
                            {
                                Destroy(CurrentPin);
                                waypointIndex--;
                            }
                            else if (PinDistance < 0)
                                if (PinDistance < DoorDistance)
                                {
                                    Destroy(CurrentPin);
                                    waypointIndex--;
                                }
                    }
                    else if (Door[i].transform.position.y == 0.89f && PreviousPin.transform.position.y == 0.65f)
                    {
                        if (PinDistance > 0)
                            if (PinDistance > DoorDistance)
                            {
                                Destroy(CurrentPin);
                                waypointIndex--;
                            }
                            else if (PinDistance < 0)
                                if (PinDistance < DoorDistance)
                                {
                                    Destroy(CurrentPin);
                                    waypointIndex--;
                                }
                    }
                    else if (Door[i].transform.position.y == 2.76f && PreviousPin.transform.position.y == 2.5f)
                    {
                        if (PinDistance > 0)
                            if (PinDistance > DoorDistance)
                            {
                                Destroy(CurrentPin);
                                waypointIndex--;
                            }
                            else if (PinDistance < 0)
                                if (PinDistance < DoorDistance)
                                {
                                Destroy(CurrentPin);
                                waypointIndex--;
                            }
                }
            }
        */
            //이전 핀과의 높이가 다르면 설치 안됨

            if (Pin.y != PreviousPin.transform.position.y)
            {
                Destroy(CurrentPin);
                waypointIndex--;
            }


            //사다리 상호작용

            for (int i = 0; i < Ladder.Length; i++)
            {
                if (Pin.x >= (Ladder[i].transform.position.x - 0.25f) && Pin.x <= (Ladder[i].transform.position.x + 0.25f))
                {
                    if (Ladder[i].transform.position.y == -2.75f)
                    {
                        if (Pin.y == -3.15f)
                        {
                            Pin.y = -1.3f;
                            waypointIndex++;
                            createPin("" + waypointIndex + "");
                        }
                        else if (Pin.y == -1.3f)
                        {
                            Pin.y = -3.15f;
                            waypointIndex++;
                            createPin("" + waypointIndex + "");
                        }
                    }
                    else if (Ladder[i].transform.position.y == -0.85f)
                    {
                        if (Pin.y == -1.3f)
                        {
                            Pin.y = 0.65f;
                            waypointIndex++;
                            createPin("" + waypointIndex + "");
                        }
                        else if (Pin.y == 0.65f)
                        {
                            Pin.y = -1.3f;
                            waypointIndex++;
                            createPin("" + waypointIndex + "");
                        }
                    }
                    else if (Ladder[i].transform.position.y == 1.05f)
                    {
                        if (Pin.y == 0.65f)
                        {
                            Pin.y = 2.5f;
                            waypointIndex++;
                            createPin("" + waypointIndex + "");
                        }
                        else if (Pin.y == 2.5f)
                        {
                            Pin.y = 0.65f;
                            waypointIndex++;
                            createPin("" + waypointIndex + "");
                        }
                    }
                }
            }
            /*
                //도어락 상호작용

                for (int i = 0; i < Door.Length; i++)
                {
                    if (Pin.x >= (Door[i].transform.position.x - 0.2f) && Pin.x <= (Door[i].transform.position.x + 0.2f))
                    {
                        if (Door[i].transform.position.y == -2.876f && Pin.y == -3.15f)
                        {
                            if (Pin.x < Door[i].transform.position.x)
                            {
                                Pin.x += 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                            else if (Pin.x > Door[i].transform.position.x)
                            {
                                Pin.x -= 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                        }
                        else if (Door[i].transform.position.y == -0.99f && Pin.y == -1.3f)
                        {
                            if (Pin.x < Door[i].transform.position.x)
                            {
                                Pin.x += 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                            else if (Pin.x > Door[i].transform.position.x)
                            {
                                Pin.x -= 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                        }
                        else if (Door[i].transform.position.y == 0.89f && Pin.y == 0.65f)
                        {
                            if (Pin.x < Door[i].transform.position.x)
                            {
                                Pin.x += 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                            else if (Pin.x > Door[i].transform.position.x)
                            {
                                Pin.x -= 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                        }
                        else if (Door[i].transform.position.y == 2.76f && Pin.y == 2.5f)
                        {
                            if (Pin.x < Door[i].transform.position.x)
                            {
                                Pin.x += 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                            else if (Pin.x > Door[i].transform.position.x)
                            {
                                Pin.x -= 0.4f;
                                waypointIndex++;
                                createPin("" + waypointIndex + "");
                            }
                        }
                    }
                }
            */
        }
    }
    public void createPin(string pinname)
    {
        GameObject newpin = Instantiate(pin, Pin, Quaternion.identity) as GameObject;
        newpin.name = pinname;
        newpin.transform.parent = parent_pin;
    }

    public static void DeletePin()
    {
        GameObject CurrentPin = GameObject.Find("" + waypointIndex + "");
        Destroy(CurrentPin);
        waypointIndex--;
    }
}
