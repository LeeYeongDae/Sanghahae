﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pin_del : MonoBehaviour
{
    Vector2 Pin;
    Vector2 player;
    List<GameObject> PinList = new List<GameObject>();
    // Start is called before the first frame update
    void Start()
    {
        Pin = this.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform.position;
        float distance = (Pin - player).sqrMagnitude;


        if (distance == 0)
        {
            this.gameObject.SetActive(false);
        }
    }
    private void OnDrawGizmosSelected()
    {
        if (PinList == null)
            return;

        for (int i = 0; i < PinList.Count; i++)
        {
            Gizmos.color = Color.blue;
            Debug.Log(PinList[i - 1].ToString() + " / to : " + PinList[i].ToString());
            Gizmos.DrawLine(PinList[i - 1].transform.position, PinList[i].transform.position);
        }
    }
}
