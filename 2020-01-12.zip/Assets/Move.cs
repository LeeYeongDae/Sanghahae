﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    private Vector2 currPosition;
    private float speed = 3f;
    public Vector2 Pin;
    GameObject pin;
    bool isClear = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        pin = GameObject.FindWithTag("Pin").gameObject;

        currPosition = transform.position;

        Vector2 pinpos;
        pinpos = pin.transform.position;

        float step = speed * Time.deltaTime;
        transform.position = Vector2.MoveTowards(currPosition, pinpos, step);

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Attach : " + other.gameObject.layer);
        if (other.gameObject.tag == "Finish")
        {
            Time.timeScale = 0f;
            isClear = true;
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        Debug.Log("Detach : " + other.gameObject.layer);
    }
}
