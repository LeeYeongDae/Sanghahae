﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class R_Guard_Move : MonoBehaviour
{
    public SpriteRenderer rend;
    private Vector2 currPosition;
    private float speed = 1.25f;

    void Update()
    {
        currPosition = transform.position;              //현 위치 파악
        float step = speed * Time.deltaTime;

        if (B_Light_toggle.B_turnoff == false)
        {
            if (R_Light_toggle.R_turnoff)
            {
                rend.flipX = false;
                transform.position = Vector2.MoveTowards(currPosition, new Vector2(-0.21f, -1.01f), step);
            }

            if (R_Light_toggle.R_turnoff == false)
            {
                rend.flipX = true;
                transform.position = Vector2.MoveTowards(currPosition, new Vector2(3.81f, -1.01f), step);
                if (currPosition == new Vector2(3.81f, -1.01f))
                    rend.flipX = false;
            }
        }
    }
}
