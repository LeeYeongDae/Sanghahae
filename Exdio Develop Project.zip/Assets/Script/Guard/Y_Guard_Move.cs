﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Y_Guard_Move : MonoBehaviour
{
    public SpriteRenderer rend;
    private Vector2 currPosition;
    private float speed = 1.25f;

    void Update()
    {
        currPosition = transform.position;              //현 위치 파악
        float step = speed * Time.deltaTime;

        if (Y_Light_toggle.Y_turnoff)
        {
            rend.flipX = true;
            transform.position = Vector2.MoveTowards(currPosition, new Vector2(5.83f, 2.73f), step);
        }

        if (Y_Light_toggle.Y_turnoff == false)
        {
            rend.flipX = false;
            transform.position = Vector2.MoveTowards(currPosition, new Vector2(2.13f, 2.73f), step);
            if (currPosition == new Vector2(2.13f, 2.73f))
                rend.flipX = true;
        }
        
    }
}
