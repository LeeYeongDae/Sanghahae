﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P_Guard_Move : MonoBehaviour
{
    public SpriteRenderer rend;
    private Vector2 currPosition;
    private float speed = 1.25f;

    void Update()
    {
        currPosition = transform.position;              //현 위치 파악
        float step = speed * Time.deltaTime;

        if (P_Light_toggle.P_turnoff)
        {
            rend.flipX = false;
            transform.position = Vector2.MoveTowards(currPosition, new Vector2(-1.31f, 0.86f), step);
        }

        if (P_Light_toggle.P_turnoff == false)
        {
            rend.flipX = true;
            transform.position = Vector2.MoveTowards(currPosition, new Vector2(0.71f, 0.86f), step);
        }
    }
}
