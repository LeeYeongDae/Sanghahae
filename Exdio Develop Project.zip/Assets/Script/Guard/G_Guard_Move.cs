﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class G_Guard_Move : MonoBehaviour
{
    public SpriteRenderer rend;
    private Vector2 currPosition;
    private float speed = 1.25f;

    void Update()
    {
        currPosition = transform.position;              //현 위치 파악
        float step = speed * Time.deltaTime;

        if (G_Light_toggle.G_turnoff)
        {
            rend.flipX = true;
            transform.position = Vector2.MoveTowards(currPosition, new Vector2(5.94f, -2.92f), step);
        }

        if (G_Light_toggle.G_turnoff == false)
        {
            rend.flipX = false;
            transform.position = Vector2.MoveTowards(currPosition, new Vector2(3.84f, -2.92f), step);
            if (currPosition == new Vector2(3.84f, -2.92f))
                rend.flipX = true;
        }
        
    }
}
