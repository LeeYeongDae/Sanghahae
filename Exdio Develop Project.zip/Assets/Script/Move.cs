﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    private Vector2 currPosition;       //플레이어의 현 위치
    private float speed = 1.5f;           //플레이어의 이동 속도
    public Vector2 Pin;
    Animator animator;
    GameObject pin;
    bool isClear = false;               //게임 클리어 여부 판별

    void Start()
    {
        animator = gameObject.GetComponentInChildren<Animator>();
    }

    void Update()
    {
        pin = GameObject.FindWithTag("Pin").gameObject; //핀 찾기

        currPosition = transform.position;              //현 위치 파악
        speed = 1.5f;
        Vector2 pinpos;
        pinpos = pin.transform.position;                //핀 위치
        
        if (pinpos.y == currPosition.y)
        {
            animator.SetBool("isClimbing", false);
            animator.SetBool("isFalling", false);
            if (pinpos.x < currPosition.x)
            {
                transform.localScale = new Vector2(-1, 1);
                animator.SetBool("isWalking", true);
            }
            else if (pinpos.x > currPosition.x)
            {
                transform.localScale = new Vector2(1, 1);
                animator.SetBool("isWalking", true);
            }
            else
                animator.SetBool("isWalking", false);
        }
        else if (pinpos.y > currPosition.y)
        {
            speed = 1.2f;
            animator.SetBool("isClimbing", true);
        }
        else if (pinpos.y < currPosition.y)
        {
            speed = 1.2f;
            animator.SetBool("isFalling", true);
        }

        float step = speed * Time.deltaTime;
        transform.position = Vector2.MoveTowards(currPosition, pinpos, step);   //핀 위치로 이동

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Attach : " + other.gameObject.layer);
        if (other.gameObject.tag == "Finish")
        {
            Time.timeScale = 0f;
            isClear = true;
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        Debug.Log("Detach : " + other.gameObject.layer);
    }
}
