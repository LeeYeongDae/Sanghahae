﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class B_Light_toggle : MonoBehaviour
{
    GameObject Light;
    float WaitTime = 8f;
    float CurrTime;
    float EnterTime;
    float OffTime = 1f;
    public static bool B_turnoff = false;

    void Start()
    {
        Light = GameObject.FindGameObjectWithTag("B_Light");
    }
    void Update()
    {
        //print("Enter" + EnterTime);
        //print("Off" + OffTime);
        if (B_turnoff)
        {
            CurrTime += Time.deltaTime;
            if (CurrTime >= WaitTime)
            {
                Light.SetActive(true);
                B_turnoff = false;
            }
        }
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            EnterTime += Time.deltaTime;
            if (EnterTime >= OffTime)
            {
                Light.SetActive(false);
                B_turnoff = true;
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
            EnterTime = 0f;
    }
}
