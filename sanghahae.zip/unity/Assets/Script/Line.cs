﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Line : MonoBehaviour
{
    private LineRenderer line;
    private Vector3 mousePos;
    public Material material;
    private int currLines = 0;
    // Start is called before the first frame update
    void Start()
    {
        line = null;
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void DrawLine()
    {
        if (line == null)
        {
            createLine();
        }
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = -9;
        line.SetPosition(0, mousePos);
        line.SetPosition(1, mousePos);
    }
    public void DrawOn()
    {
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = -9;
        line.SetPosition(1, mousePos);
    }

    public void LineFinish()
    {
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = -9;
        line.SetPosition(1, mousePos);
        line = null;
        currLines++;
    }

    void createLine()
    {
        line = new GameObject("Line" + currLines).AddComponent<LineRenderer>();
        line.material = material;
        line.positionCount = 2;
        line.startWidth = 5.0f;
        line.endWidth = 5.0f;
        line.useWorldSpace = false;
        line.numCapVertices = 50;
    }
}
